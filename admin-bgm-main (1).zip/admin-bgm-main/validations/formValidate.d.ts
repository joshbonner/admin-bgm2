export interface IFormValidate {
  isValid: boolean;
  errors: object;
}
