# Berrygood Media Stat Admin Panel

![image](https://github.com/btmelody/admin-bgm/assets/127592767/5bd27c1a-d81c-48f8-b964-a865ecaf1893)
