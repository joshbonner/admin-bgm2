import { LicenseInfo } from "@mui/x-license-pro";
LicenseInfo.setLicenseKey(process.env.REACT_APP_MUI_X_LICENSE_KEY,
);

export default function MuiXLicense() {
  return null;
}
